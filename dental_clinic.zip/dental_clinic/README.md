# Dental Clinic Platform

## Introduction
This platform is designed for a dental clinic, providing information about the clinic, allowing users to book appointments, and contact the clinic.

## Features
- Home page with a welcome message.
- About page with information about the clinic.
- Contact page with a form to send messages to the clinic.
- Appointment booking page with a form to book appointments.
- Patient registration page.

## Structure
- `/classes`: Contains PHP classes for handling appointments, patients, and custom exceptions.
- `/css`: Contains the stylesheet for the platform.
- `/includes`: Contains reusable components like the header, footer, and database connection.
- `about.php`: About page.
- `book_appointment.php`: Appointment booking page.
- `contact.php`: Contact page.
- `index.php`: Home page.
- `processorder.php`: Script to process form submissions.
- `register_patient.php`: Patient registration page.

## Code Explanation
- **Appointment.php**: Defines the `Appointment` class for handling appointment details.
- **CustomExceptions.php**: Defines custom exception classes for handling errors.
- **Patient.php**: Defines the `Patient` class for handling patient details and registration.
- **db.php**: Contains the `connect_db` function for connecting to the database.
- **header.php**: Contains the HTML for the header, including the navigation menu.
- **footer.php**: Contains the HTML for the footer.

## Challenges and Solutions
- **Challenge**: Centering the content on the page.
  - **Solution**: Used CSS flexbox properties to center the content both horizontally and vertically.
- **Challenge**: Making the form look attractive and user-friendly.
  - **Solution**: Applied CSS styles to the form elements to enhance their appearance.