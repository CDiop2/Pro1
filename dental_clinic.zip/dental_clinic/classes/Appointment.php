<?php
class Appointment
{
    private $date;
    private $time;
    private $clientName;

    public function __construct($date, $time, $clientName)
    {
        $this->date = $date;
        $this->time = $time;
        $this->clientName = $clientName;
    }

    public function getDetails()
    {
        return "Appointment on {$this->date} at {$this->time} with {$this->clientName}.";
    }
}

// Example usage
$appointment = new Appointment('2023-10-01', '10:00 AM', 'John Doe');
echo $appointment->getDetails();
?>