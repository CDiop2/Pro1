<?php
class CustomException extends Exception
{
    public function __toString()
    {
        return "CustomException {$this->getCode()}: {$this->getMessage()}<br /> in {$this->getFile()} on line {$this->getLine()}<br />";
    }
}

class AnotherCustomException extends Exception
{
    public function __toString()
    {
        return "AnotherCustomException {$this->getCode()}: {$this->getMessage()}<br /> in {$this->getFile()} on line {$this->getLine()}<br />";
    }
}

// Example usage
try {
    throw new CustomException("This is a custom exception", 1);
} catch (CustomException $e) {
    echo $e;
}

try {
    throw new AnotherCustomException("This is another custom exception", 2);
} catch (AnotherCustomException $e) {
    echo $e;
}
?>