<?php
require('includes/header.php');
require('includes/db.php');
require('classes/Appointment.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $date = $_POST['date'];
  $time = $_POST['time'];
  $clientName = $_POST['clientName'];

  $appointment = new Appointment($date, $time, $clientName);

  // Save appointment to the database
  $db = connect();
  $stmt = $db->prepare("INSERT INTO appointments (date, time, clientName) VALUES (?, ?, ?)");
  $stmt->bind_param('sss', $date, $time, $clientName);
  $stmt->execute();
  $stmt->close();
  $db->close();

  echo "<p>Appointment booked successfully!</p>";
}
?>
<div class="container">
<section>
  <h2>Book an Appointment</h2>
  <form method="post" action="book_appointment.php">
    <label for="date">Date:</label>
    <input type="date" id="date" name="date" required>
    <label for="time">Time:</label>
    <input type="time" id="time" name="time" required>
    <label for="clientName">Your Name:</label>
    <input type="text" id="clientName" name="clientName" required>
    <button type="submit">Book Appointment</button>
  </form>
</section>
</div>
<?php
require('includes/footer.php');
?>