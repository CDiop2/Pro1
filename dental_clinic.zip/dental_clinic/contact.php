<?php
require('includes/header.php');
?>
<div class="container">
  <section>
    <h2>Contact Us</h2>
    <p>If you have any questions or would like to schedule an appointment, please contact us using the information below:</p>
    <p>Email: info@dentalclinic.com</p>
    <p>Phone: (123) 456-7890</p>
    <p>Address: 123 Dental St, Smile City, SC 12345</p>
    <div class="form-container">
      <form method="post" action="send_contact.php">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required>
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>
        <label for="message">Message:</label>
        <textarea id="message" name="message" required></textarea>
        <button type="submit">Send Message</button>
      </form>
    </div>
  </section>
</div>
<?php
require('includes/footer.php');
?>