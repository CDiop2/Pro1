<!DOCTYPE html>
<html>
<head>
  <title>Dental Clinic</title>
  <link href="css/styles.css" type="text/css" rel="stylesheet">
</head>
<body>
  <header>
    <div class="header-container">
      <img src="images/logo.png" alt="Dental Clinic Logo" class="logo" id="logo">
      <h1>Dental Clinic</h1>
      <nav>
        <ul class="nav-menu">
          <li><a href="index.php">Home</a></li>
          <li><a href="about.php">About</a></li>
          <li><a href="contact.php">Contact</a></li>
          <li><a href="book_appointment.php">Book Appointment</a></li>
          <li><a href="register_patient.php">Register as Patient</a></li>
        </ul>
      </nav>
    </div>
  </header>
</body>
</html>