  <footer>
    <p>&copy; 2024 Dental Clinic.</p>
  </footer>
</body>
</html>