<?php
function connect_db() {
  $db = new mysqli('localhost', 'root', '', 'dental_clinic');
  if ($db->connect_error) {
    throw new Exception("Connection failed: " . $db->connect_error);
  }
  return $db;
}
?>