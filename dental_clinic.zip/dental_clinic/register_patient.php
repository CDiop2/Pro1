<?php
require('includes/header.php');
require('includes/db.php');
require('classes/Patient.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $name = $_POST['name'];
  $email = $_POST['email'];
  Patient::register($name, $email);
  echo "<p>Registration successful!</p>";
}
?>
<div class="container">
  <section>
    <h2>Register as a Patient</h2>
    <form method="post" action="register_patient.php">
      <label for="name">Name:</label>
      <input type="text" id="name" name="name" required>
      <label for="email">Email:</label>
      <input type="email" id="email" name="email" required>
      <button type="submit">Register</button>
    </form>
  </section>
</div>
<?php
require('includes/footer.php');
?>