<?php
require('includes/header.php');
?>
<div class="container">
  <section>
    <h2>Welcome to the Dental Clinic</h2>
    <p>Your smile is our priority.</p>
  </section>
</div>
<?php
require('includes/footer.php');
?>