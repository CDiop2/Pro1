<?php
require('includes/header.php');
?>
<div class="container">
<section>
  <h2>About Our Dental Clinic</h2>
  <p>Welcome to our dental clinic. We are dedicated to providing the best dental care for our patients. Our team of experienced dentists and friendly staff are here to ensure you have a comfortable and pleasant experience.</p>
  <p>Our clinic offers a wide range of services including routine check-ups, cleanings, fillings, root canals, and cosmetic dentistry. We use the latest technology and techniques to provide high-quality care.</p>
  <p>We look forward to serving you and your family. Thank you for choosing our dental clinic.</p>
</section>
</div>
<?php
require('includes/footer.php');
?>